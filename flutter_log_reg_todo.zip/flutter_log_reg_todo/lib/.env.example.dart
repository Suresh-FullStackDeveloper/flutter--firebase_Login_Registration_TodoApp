class Configure {
  static const String AppName = 'Flutter Todo';
  static const String FirebaseUrl =
      'https://admins-view-or-manageallusers-default-rtdb.firebaseio.com/';
  static const String ApiKey = 'AIzaSyBlySgYWogKHvAHea00OiO0m6F51Mv2FxY';
}
